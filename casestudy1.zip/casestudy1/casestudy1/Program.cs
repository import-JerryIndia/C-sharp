﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace casestudy1
{
    class savings_account
    {
        private float balance, interest_amount;
        private static float interest_rate;
        public string name;
        public savings_account(float rate,string name)
        {
            balance = 0;
            interest_amount = 0;
            interest_rate = rate;
            this.name = name;
        }

        public float calculate_interest()
        {
            interest_amount = balance * ((interest_rate/12) / 100);
            balance += interest_amount;
            return interest_amount;
        }

        public float savings(float amount)
        {
            this.balance += amount;
            return this.balance;
        }

        public float passbook_print()
        {
            return balance;
        }

        public static void modifyinterest(float newint)
        {
            interest_rate = newint;
        }
    }
    class Program
    {
        
        static void Main(string[] args)
        {
            int id=10000;
            int j = 1;
            float rate_main;

            Console.WriteLine("=: Enter Interest rate :=");
            rate_main = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine(" How many Users you want to add :=");
            int no = Convert.ToInt32(Console.ReadLine());
            savings_account[] s1 = new savings_account[no];
            while (true)
            {
                for(int i=0;i<no;i++)
                {
                    Console.WriteLine("=: Enter User name :=");
                    String name1 = Console.ReadLine().ToString();

                    


                    s1[i] = new savings_account(rate_main, name1);
                }

                while(true)
                {
                    Console.WriteLine(" Enter username to perform operations :=");
                    String namedemo = Console.ReadLine().ToString();
                    //int i = 0;
                    for (int i = 0; i < no; i++)
                    {
                        Console.WriteLine("for loop stared :=");
                        if (s1[i].name == namedemo)
                        {

                            id = i;
                            j = 1;
                        }
                       

                    }
                   

                    
                    while(j!=0)
                    {
                        Console.WriteLine("=: Select Option :=\n1.add money\n2.know your balanace\n3.know added interest\n4.Change Interest rate \n5.exit ");
                        int choice = Convert.ToInt32(Console.ReadLine());

                        switch (choice)
                        {
                            case 1:
                                {
                                    Console.WriteLine(" How much money you want to add :=");
                                    int money = Convert.ToInt32(Console.ReadLine());

                                    float temp = s1[id].savings(money);
                                    Console.WriteLine("Accout Balance is :=" + temp);
                                    break;
                                }

                            case 2:
                                {

                                    float temp = s1[id].passbook_print();
                                    Console.WriteLine("Accout Balance is :=" + temp);
                                    break;
                                }

                            case 3:
                                {
                                    float temp = s1[id].calculate_interest();
                                    Console.WriteLine("Interest amount is :=" + temp);
                                    break;
                                }

                            case 4:
                                {
                                    Console.WriteLine("=: Enter new Interest rate :=");
                                    rate_main = Convert.ToInt32(Console.ReadLine());
                                    savings_account.modifyinterest(rate_main);
                                    break;
                                }

                            case 5:
                                {
                                    j = 0;
                                    break;
                                }
                        }
                    }
                    
                }
                

            }


        }
    }
}
