﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace gridview
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            dataGridView1.Columns.Add("Name","Name");
            dataGridView1.Columns.Add("Roll", "Roll");
        }

        private void button1_Click(object sender, EventArgs e)
        {
            addRow(textBox1.Text.ToString(),Convert.ToInt32(textBox2.Text));
        }

        private void addRow(string name,int roll)
        {
            //https://www.youtube.com/watch?v=K82yB4BGQDs&list=WL&index=29&t=301s

            object[] data = { name, roll };
            dataGridView1.Rows.Add(data);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection connection = new MySqlConnection(@"server=localhost;user id=root;pwd=@aniket52012;persistsecurityinfo=True;database=jerry;allowuservariables=True");
            connection.Open();
            for(int i=0;i<dataGridView1.Rows.Count-1;i++)
            {
                MySqlCommand cmd = new MySqlCommand("insert into exportdata values('"+dataGridView1.Rows[i].Cells[0].Value+"','"+ Convert.ToInt32(dataGridView1.Rows[i].Cells[1].Value) + "')", connection);
                cmd.ExecuteNonQuery();
            }
            MessageBox.Show("Exported Successfully...");
            connection.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Clear();
            dataGridView1.Refresh();
        }
    }
}
